// Part of BNC, a utility for retrieving decoding and
// converting GNSS data streams from NTRIP broadcasters.
//
// Copyright (C) 2007
// German Federal Agency for Cartography and Geodesy (BKG)
// http://www.bkg.bund.de
// Czech Technical University Prague, Department of Geodesy
// http://www.fsv.cvut.cz
//
// Email: euref-ip@bkg.bund.de
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation, version 2.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

/* -------------------------------------------------------------------------
 * BKG NTRIP Client
 * -------------------------------------------------------------------------
 *
 * Class:      main
 *
 * Purpose:    Application starts here
 *
 * Author:     L. Mervart
 *
 * Created:    24-Dec-2005
 *
 * Changes:
 *
 * -----------------------------------------------------------------------*/

#include <unistd.h>
#include <signal.h>
#include <QApplication>
#include <iostream>

#include "bnccore.h"
#include "bncmain.h"


using namespace std;


// Main Program
/////////////////////////////////////////////////////////////////////////////
int main_bnc(int argc, char* argv[]) {
    cout << "100000 bncMain entry\n";

    QApplication app(argc, argv);
    // /home/t0535zw/workspace/BNC_2.12.18/log/BNC.bnc
    // /home/t0535zw/workspace/athena_ros_ws/src/ntripclient/BNC.bnc
    BNC_CORE->setConfFileName( "/home/t0535zw/workspace/BNC_2.12.18/log/BNC02.bnc" );
    bncCaster* caster2 = new bncCaster();
    caster2->startStlaCaster();

    return app.exec();
    //return 0;
}
