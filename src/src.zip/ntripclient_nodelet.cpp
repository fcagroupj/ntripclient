/**
 * @brief 
 *        ntripclient_nodelet.cpp
 *
 */
#include "ntripclient_nodelet.h"
#include "ntripclient.h"
#include "bncmain.h"
/**
 * @brief namespace for template
 */
namespace ntripclient
{
/**
 * @brief Nodelet entry point function
 *
 */

void ntripclientNodelet :: onInit()
{
	NODELET_WARN("Initalizing Nodelet ntripclient");
	
	// loop for ROS process
	if (true)
	{
		// call 
		char argv[5][64] = { "-s https://mi.smartnetna.com/", "-u ste01565018", 
			"-p 801655", "-r 9950", "-M h" };
		main_bnc(0, (char **)argv);
		ros::Duration(3.0).sleep();
	}
	return;
}
};  // namespace ntripclient

/**
 * @brief Construct a new pluginlib export class object
 *
 */
PLUGINLIB_EXPORT_CLASS(ntripclient::ntripclientNodelet, nodelet::Nodelet);