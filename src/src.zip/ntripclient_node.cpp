/**
 * @brief Node for CE perception
 *
 * @file ntripclient_node.cpp
 * @author Jeff
 * @date 2022-06-08
 */

#include <nodelet/loader.h>
#include <ros/ros.h>

/**
 * @brief main entry point for CE perception node
 *
 * @param argc argument count
 * @param argv argument list
 * @return int return code
 */
int main(int argc, char **argv)
{
  ros::init(argc, argv, "ntripclient_node");

  nodelet::Loader nodelet;
  nodelet::M_string remap(ros::names::getRemappings());
  nodelet::V_string nargv;
  std::string nodelet_name = ros::this_node::getName();
  nodelet.load(nodelet_name, "ntripclient/ntripclientNodelet", remap, nargv);

  ros::spin();

  return 0;
}
